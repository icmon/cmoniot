# docker Install CmonIoT

```bash

ขั้นตอนที่ 1 ใช้งาน Docker image ชื่อว่า jenkinsci/jenkins ใช้ tag latest
ดังนั้นทำการ pull หรือ download image ลงมาที่เครื่องของเราก่อน

1
 docker pull jenkinsci/jenkins:latest
ขั้นตอนที่ 2 ทำการสร้าง image และ container ที่ต้องการ
โดยต้องการให้มี 2 ตัวคือ

ตัวที่ 1 คือ Jenkins server หลัก หรือ Jenkins master
ตัวที่ 2 คือ เก็บข้อมูลต่าง ๆ ของ Jenkins เช่น job และ plugin เพื่อไม่ให้ไปผูกติดกับ Jenkins master เรียกว่า Jenkins Data
ดังนั้นเมื่อเราทำการลบ และ สร้าง container ของ Jenkins master ขึ้นมาใหม่
ก็ยังสามารถใช้งานค่า configuration จาก Jenkins data ได้
ถือว่าเป็นอีกหนึ่งแนวทางในการจัดการ

เริ่มด้วยการสร้าง image กันก่อน

1.

docker build -t jenkins-data -f data/Dockerfile .

2.

docker build -t jenkins2 -f master/Dockerfile .


โดยที่ Dockerfile ของ Jenkins master และ Jenkins data อยู่ที่ Github

จากนั้นทำการสร้าง container จาก image ที่สร้างไว้ก่อนหน้า
โดย Jenkins master จะต้องทำการกำหนด volume ไปยัง Jenkins data ด้วย

$ docker run --name=jenkins-data jenkins-data
$ docker run -p 8080:8080 -p 50000:50000 --name=jenkins-master --volumes-from=jenkins-data -d jenkins2
เมื่อสร้าง container เสร็จแล้ว ตรวจสอบด้วยคำสั่ง

1
$ docker ps -a
แสดงผลการทำงานดังนี้


$ docker pa -a

CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS                         PORTS                                              NAMES
e614797e3af7        jenkins2            "/bin/tini -- /usr/lo"   22 minutes ago      Up 22 minutes                  0.0.0.0:8080->8080/tcp, 0.0.0.0:50000->50000/tcp   jenkins-master
9fae0c4f4d66        jenkins-data        "echo 'Data container"   About an hour ago   Exited (0) About an hour ago                                                      jenkins-data
view rawlist-container.txt hosted with ❤ by GitHub
โดยสามารถตรวจสอบการทำงานผ่าน browser ด้วย URL = http://localhost:8080 (ผมใช้ Docker for Mac นะ)
จะแสดงดังรูป

jenkins2-01

ขั้นตอนที่ 3 ทำการ configuration ค่าต่าง ๆ ของ Jenkins 2
เริ่มการดึงค่าของ Administrator password ก่อนเลย
ด้วยคำสั่ง

1
$ docker exec jenkins-master cat /var/jenkins_home/secrets/initialAdminPassword
ทำการติดตั้ง Plugin และ สร้าง Job ที่ต้องการกันได้เลย
ซึ่งผมเลือกการติดตั้ง plugin ตามที่ Jenkins 2 แนะนำเลย
จากนั้นให้สร้าง user สำหรับจัดการ Jenkins
จากนั้นก็มาเริ่มใช้งานกันเลย
แสดงดังรูป
 
Pass: 2defe962bb5541b898c529c3029ee46d

jenkins2-03

จากนั้นสร้าง Item ซึ่งผมเลือกสร้าง Pipeline-as-code ขึ้นมา (เป็น plugin ใหม่ของ Jenkins 2)
ชื่อว่า My-pipeline
แสดงดังรูป

jenkins2-04

เมื่อสร้างเสร็จแล้วก็ทดสอบ run สิ รออะไร
แสดงดังรูป

jenkins2-05

เมื่อทุกอย่างเรียบร้อย ให้ลอง stop, ลบ และสร้าง container ของ Jenkins-master
จะพบว่าข้อมูลต่าง ๆ ทั้ง plugin และ job ยังคงอยู่
และสามารถใช้งานได้เหมือนเดิม ไม่ต้องมาสร้างใหม่
ซึ่งถ้าเข้ามาที่ Jenkins server จะต้องใส่ username และ password ด้วยนะ

แต่อย่าไปลบ container ชื่อว่า jenkins-data นะ !!

สุดท้ายแล้ว เราก็สามารถเริ่มสร้างระบบ Continuous Integration ด้วย Jenkins อย่างง่ายได้
ต่อไปจะอธิบายการสร้าง Pipeline-as-code เพื่อทำงานร่วมกับ Version Control เช่น git
รวมทั้งการสร้าง Jenkins slave และการจัดการผ่าน Docker compose
ยังไม่อะไรให้เราเรียนรู้อีกเยอะ !!

Reference Websites
https://dzone.com/articles/get-started-with-jenkins-20-with-docker
http://engineering.riotgames.com/news/putting-jenkins-docker-container
https://www.future-processing.pl/blog/building-and-deployment-multi-branch-web-application/
http://www.focusedsupport.com/blog/beyond-builds-combining-jenkins-and-docker-for-continuously-running-instances/
https://www.cloudbees.com/blog/get-ripped-jenkins-docker-industrial-strength-continuous-delivery
http://making.meetup.com/post/122890386432/steps-towards-automated-testing-with-docker-and



Jenkins Master
docker build -t jenkins2 -f master/Dockerfile .
Jenkins Data
docker build -t jenkins-data -f data/Dockerfile .


 list image
 docker ps
 
 - https://rukpong.medium.com/มาติดตั้ง-jenkins-บน-docker-กัน-ae9c34b459b3
 https://rukpong.medium.com/%E0%B8%A1%E0%B8%B2%E0%B8%95%E0%B8%B4%E0%B8%94%E0%B8%95%E0%B8%B1%E0%B9%89%E0%B8%87-jenkins-%E0%B8%9A%E0%B8%99-docker-%E0%B8%81%E0%B8%B1%E0%B8%99-ae9c34b459b3
 
 docker run -p 8080:8080 -p 50000:50000 --name=jenkins-master --volumes-from=jenkins-data -d jenkins2


 docker ps -a

 docker exec jenkins-master cat /var/jenkins_home/secrets/initialAdminPassword
 - root
 - 2defe962bb5541b898c529c3029ee46d
 

 คำสั่งเพิ่มเติมสำหรับ Docker ที่ใช้งานบ่อย

สั่งลบ image
docker rmi [ID_or_Name_Image]
สั่ง Start/Stop container
docker start [ID_or_Name_Container]
docker stop [ID_or_Name_Container]
สั่งลบ container
docker rm [ID_or_Name_Container]

- http://localhost:8080/
U: admincmon
P: admincmon
- icmon0955@gmail.com



wsl 

การแก้ไขเบื้องต้น

รีสตาร์ท Docker และ WSL

ปิด Docker Desktop ก่อน.

ปิด WSL โดยใช้คำสั่งใน Command Prompt หรือ PowerShell: wsl --shutdown.

จากนั้น เปิด Docker Desktop ใหม่อีกครั้ง.

คุณอาจลองรีสตาร์ทบริการ LxssManager ด้วยคำสั่ง net stop LxssManager && net start LxssManager (ต้องรันในฐานะผู้ดูแลระบบ) แล้วค่อยเปิด Docker อีกครั้ง.

ตรวจสอบการรวม WSL ใน Docker Desktop

เปิด Docker Desktop ไปที่ Settings > Resources > WSL Integration และตรวจสอบให้แน่ใจว่าได้เปิดใช้งานการรวมสำหรับ Ubuntu distribution ไว้แล้ว.

การแก้ไขปัญหาขั้นสูง

ลบไฟล์ .wslconfig

หากคุณเคยสร้างไฟล์ .wslconfig ในพาธ C:\Users\<username> เพื่อจำกัดการใช้หน่วยความจำของ Docker บน WSL2 ลองลบไฟล์นี้ออก. บางครั้งไฟล์นี้อาจขัดแย้งกับการอัปเดต Docker ใหม่ ทำให้ Docker ไม่สามารถเริ่มต้นได้.

เปิดใช้งาน systemd ใน WSL

บางครั้งปัญหาอาจเกิดจากการที่ systemd ไม่ได้ถูกเปิดใช้งานใน WSL สำหรับ Ubuntu.

เข้าสู่ WSL โดยใช้คำสั่ง wsl ใน Command Prompt หรือ PowerShell.

แก้ไขไฟล์ /etc/wsl.conf (หากไม่มี ให้สร้างขึ้นมา) โดยใช้คำสั่ง sudo vi /etc/wsl.conf.

เพิ่มบรรทัดต่อไปนี้:

text
[boot]
systemd=true
บันทึกการเปลี่ยนแปลง (สำหรับ vi ให้กด esc แล้วพิมพ์ :wq).

ออกจาก WSL ด้วยคำสั่ง exit.

ปิด WSL อีกครั้งด้วย wsl --shutdown.

เริ่ม WSL ใหม่ด้วย wsl.

จากนั้น ลองเปิด Docker Desktop อีกครั้ง.

ย้อนกลับเวอร์ชัน WSL

หากปัญหาเพิ่งเกิดขึ้นหลังจากการอัปเดต WSL อาจเป็นเพราะเวอร์ชัน WSL นั้นมีข้อบกพร่อง.

ปิด Docker Desktop.

ตรวจสอบเวอร์ชัน WSL ปัจจุบันด้วย wsl --version.

ถอนการติดตั้ง WSL ด้วย wsl --uninstall (ข้อมูล distro ของคุณจะไม่หายไป).

ไปที่เว็บไซต์ WSL อย่างเป็นทางการ (GitHub Releases) และดาวน์โหลดเวอร์ชันก่อนหน้ามาติดตั้งใหม่ (โดยปกติจะเป็นไฟล์ .msixbundle).

เมื่อติดตั้งเสร็จแล้ว ให้รัน Docker Desktop ในฐานะผู้ดูแลระบบ.

ลบ Docker Distro (อาจทำให้ข้อมูลหาย)

ในบางกรณี การลบ Docker distros ใน WSL อาจช่วยได้ แต่ควรระวังเพราะข้อมูลคอนเทนเนอร์ของคุณอาจหายไป.

ใน PowerShell ให้ใช้คำสั่ง:

powershell



wsl --unregister docker-desktop

wsl --unregister docker-desktop-data



มีรายงานว่าผู้ใช้บางรายแก้ไขปัญหาได้ด้วยการลบ WSL distro อื่นๆ (เช่น Ubuntu-24.04) และคงเหลือไว้เพียง "docker-desktop" distro เท่านั้น.

การพิจารณาทางเลือกอื่น

หากปัญหานี้เกิดขึ้นบ่อยครั้งและคุณไม่ได้ใช้ Windows containers คุณอาจพิจารณาติดตั้ง Docker Engine โดยตรงใน Ubuntu ที่รันบน WSL2 แทนที่จะใช้ Docker Desktop ที่รวมเข้ากับ WSL.


ขั้นตอนการลบ Ubuntu distribution:

เปิด PowerShell หรือ Command Prompt ในฐานะผู้ดูแลระบบ .

ตรวจสอบชื่อของ distribution ให้แน่ใจ: คุณสามารถใช้คำสั่ง wsl -l -v หรือ wsl --list --verbose เพื่อดูรายการ distribution ทั้งหมดและชื่อที่ถูกต้อง . จากภาพที่คุณให้มา ชื่อคือ Ubuntu .

รันคำสั่งเพื่อลบ distribution: พิมพ์คำสั่งต่อไปนี้แล้วกด Enter:

powershell

wsl --unregister Ubuntu


(โปรดจำไว้ว่าชื่อ distribution เป็น case-sensitive หรือคำนึงถึงตัวพิมพ์เล็ก-ใหญ่ ).

หลังจากดำเนินการนี้ Ubuntu จะไม่ปรากฏในรายการเมื่อคุณรัน wsl -l อีกต่อไป . หากคุณต้องการใช้ Ubuntu ใน WSL อีกครั้ง คุณจะต้องติดตั้งใหม่จาก Microsoft Store .

วิธีอื่นในการลบ (ไม่แนะนำให้ใช้โดยลำพังหากต้องการลบข้อมูลทั้งหมด):

ถอนการติดตั้งผ่าน Start Menu หรือ Settings (Apps & features): คุณสามารถค้นหา "Ubuntu" ใน Start Menu, คลิกขวา, แล้วเลือก "Uninstall" . หรือไปที่ Settings > Apps > Apps & features, ค้นหา Ubuntu, แล้วเลือก Uninstall .


ข้อควรระวัง: วิธีนี้จะลบตัวแอปพลิเคชัน แต่จะไม่ลบข้อมูลและไฟล์ระบบทั้งหมดที่ WSL สร้างขึ้นอย่างสมบูรณ์ . ดังนั้น หากคุณต้องการลบทุกอย่างจริงๆ คุณควรถอนการติดตั้งผ่าน 

wsl --unregister ก่อน แล้วจึงถอนการติดตั้งแอปพลิเคชันจาก Store เพื่อการทำความสะอาดที่สมบูรณ์ .


https://medium.com/@thananchai.sskru/วิธีทำ-ci-cd-ด้วย-jenkins-สำหรับbuild-docker-container-อย่างง่าย-4896b1c65571

- http://localhost:8080/job/frontendcmon/configure

https://github.com/kongnakornna/appcmoniot

* * * * * 

pipeline {
    agent any

    stages {
        stage('Pull From Git') {
            steps {
                git branch: 'main', url: 'https://github.com/kongnakornna/appcmoniot'
            }
        }
       stage('Docker Compose') {
            steps {
                sh 'docker-compose up --build -d'
            }
        }
        stage('Success') {
            steps {
                echo 'Deploy Successfully'
            }
        }
    }
}


ข้อผิดพลาด "Support for password authentication was removed" (รองรับการยืนยันตัวตนด้วยรหัสผ่านถูกลบออกแล้ว) ใน GitHub เกิดขึ้นเนื่องจาก GitHub ได้ยกเลิกการรองรับการยืนยันตัวตนด้วยรหัสผ่านสำหรับ Git operations ตั้งแต่วันที่ 13 สิงหาคม 2021 ปัจจุบัน คุณจะต้องใช้ Personal Access Token (PAT) แทนรหัสผ่านในการดำเนินการกับ Git เช่น การ git pull หรือ git push ไปยัง GitHub repository

ต่อไปนี้คือวิธีการแก้ไขปัญหานี้:

1. สร้าง Personal Access Token (PAT) บน GitHub
คุณจะต้องสร้าง PAT ในการตั้งค่าบัญชี GitHub ของคุณ:

เข้าสู่ระบบ GitHub ของคุณ

คลิกที่รูปโปรไฟล์ของคุณและเลือก "Settings" (การตั้งค่า)

ในแถบด้านข้าง ให้เลื่อนลงและคลิก "Developer Settings" (การตั้งค่านักพัฒนา)

เลือก "Personal access tokens" (โทเค็นการเข้าถึงส่วนตัว) จากนั้นคลิก "Tokens (classic)"

คลิก "Generate new token" (สร้างโทเค็นใหม่) และเลือก "Generate new token (classic)"

ระบุชื่อสำหรับ PAT ในช่อง "Note" (บันทึก) เพื่อระบุวัตถุประสงค์การใช้งาน

ตั้งค่าการหมดอายุของโทเค็น (แนะนำให้เลือก "No expiration" หากไม่ต้องการสร้างใหม่บ่อยๆ)

เลือกขอบเขตสิทธิ์ (scope) ที่จำเป็น ตัวอย่างเช่น เลือกช่องทำเครื่องหมายทั้งหมดเพื่อให้ PAT มีสิทธิ์เข้าถึง repository ได้เต็มที่

คลิก "Generate token" (สร้างโทเค็น)

สำคัญมาก: คัดลอก PAT ที่สร้างขึ้นมาทันที เนื่องจากจะไม่สามารถเห็นค่านี้ได้อีกหลังจากออกจากหน้านี้

2. ใช้ Personal Access Token (PAT) แทนรหัสผ่าน
เมื่อคุณดำเนินการ Git ที่ต้องมีการยืนยันตัวตน (เช่น git pull หรือ git push) Git จะแจ้งให้คุณใส่ชื่อผู้ใช้และรหัสผ่าน:

สำหรับชื่อผู้ใช้ (username) ให้ใส่ชื่อผู้ใช้ GitHub ของคุณ

สำหรับรหัสผ่าน (password) ให้วาง PAT ที่คุณคัดลอกมาในขั้นตอนก่อนหน้า

3. ล้างข้อมูลรับรองที่ถูกแคชไว้ (หากยังคงเกิดปัญหา)
บางครั้งข้อมูลรับรองเก่าอาจถูกเก็บไว้ในระบบ ทำให้เกิดปัญหาในการยืนยันตัวตนแม้ว่าจะใช้ PAT แล้วก็ตาม:

สำหรับ Windows:

เปิด "Control Panel" (แผงควบคุม) > "User Accounts" (บัญชีผู้ใช้) > "Credential Manager" (ตัวจัดการข้อมูลรับรอง)

มองหาข้อมูลรับรองที่เกี่ยวข้องกับ git:https://github.com หรือ github.com

คุณอาจต้อง "Delete" (ลบ) ข้อมูลรับรองนั้นออก แทนที่จะแค่ "Edit" (แก้ไข) มัน

หลังจากลบแล้ว ลองดำเนินการ Git อีกครั้ง ระบบจะแจ้งให้ใส่ชื่อผู้ใช้และ PAT ใหม่ ซึ่งจะถูกบันทึกไว้สำหรับการใช้งานในอนาคต

สำหรับ macOS:

เปิด "Keychain Access" (การเข้าถึงพวงกุญแจ) โดยค้นหาใน Spotlight

ค้นหา "github.com"

ค้นหารายการรหัสผ่านอินเทอร์เน็ตสำหรับ github.com แล้วอัปเดต หรือลบรายการที่มีอยู่หากการอัปเดตไม่ได้ผล

เมื่อคุณทำตามขั้นตอนเหล่านี้ คุณจะสามารถเข้าถึงและจัดการ GitHub repository ของคุณได้โดยไม่มีข้อผิดพลาดในการยืนยันตัวตน.




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
 


- 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

- https://github.com/settings/personal-access-tokens

```

