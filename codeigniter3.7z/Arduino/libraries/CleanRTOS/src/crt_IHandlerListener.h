// by Marius Versteegen, 2022

#pragma once
namespace crt
{
	class IHandlerListener
	{
	public:
		virtual void update()=0;
	};
};