  <!-- BEGIN PAGE LIBRARIES -->
  <script src="<?php echo base_url('assets');?>/libs/apexcharts/dist/apexchartsv1.js" defer></script>
  <script src="<?php echo base_url('assets');?>/libs/jsvectormap/dist/jsvectormap.min.js" defer></script>
  <script src="<?php echo base_url('assets');?>/libs/jsvectormap/dist/maps/world.js" defer></script>
  <script src="<?php echo base_url('assets');?>/libs/jsvectormap/dist/maps/world-merc.js" defer></script>
  <!-- END PAGE LIBRARIES -->