<div class="card-table table-responsive">
    <table class="table table-vcenter">
        <thead>
            <tr>
                <th>No</th>
                <th>STATUS</th>

            </tr>
        </thead>
        <tbody>

            <tr>
                <td class="w-1">
                    1
                </td>
                <td class="td-truncate">
                    <div class="text-truncate">
                        Podium floor 12 FAN 1 ON
                    </div>
                </td>

            </tr>

            <tr>
                <td class="w-1">
                    2
                </td>
                <td class="td-truncate">
                    <div class="text-truncate">
                        Podium floor 7 FAN 2 OFF
                    </div>
                </td>

            </tr>
            <!-- <tr>
                <td class="w-1">
                    3
                </td>
                <td class="td-truncate">
                    <div class="text-truncate">
                        Podium floor 16 FAN 2 ON
                    </div>
                </td>

            </tr> -->
            <!--     <tr>
                        <td class="w-1">
                            4
                        </td>
                        <td class="td-truncate">
                            <div class="text-truncate">
                                Podium floor 20 FAN 2 ON
                            </div>
                        </td>

                    </tr> -->
        </tbody>
    </table>
</div>