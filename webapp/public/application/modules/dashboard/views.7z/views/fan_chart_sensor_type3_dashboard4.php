<script type="text/javascript" src="<?php echo base_url('assets/sweetalert2/dist/js/jquery-latest.js');?>"></script>
<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert-dev.js');?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert.css');?>">
<?php 
    $input=@$this->input->post(); 
    if($input==null){$input=@$this->input->get();}
    $sensor_name=@$input['bucket'];
    $token=$_SESSION['token'];
    $deletecache=@$input['deletecache']; 
    $segment1 = $this->uri->segment(1);
    $segment2 = $this->uri->segment(2);
    $token = $_SESSION['token'];
    $api_call = $this->config->item('api_url') . 'mqtt';
    $rsapi = $this->Crul_model->call_api_with_token($api_call, $token);
    if ($rsapi['code'] != 200) {
        echo 'Error: Could not retrieve initial data from API.'; 
        die();
    }
    $payload = $rsapi['payload']['0'];
    $mqtt_name=$payload['mqtt_name'];
    $mqtt_bucket=$payload['device']['0']['mqtt_bucket'];
    $device_name=$payload['device']['0']['device_name'];
    $type_name=$payload['device']['0']['type_name'];
    $mqtt_data_value=$payload['device']['0']['mqtt_data_value'];
    $bucket=$mqtt_bucket;
?>
<style>
</style>
<div class="col-lg-7">
    <div class="card">
        <?php ########### -----table -----############?>
        <div class="ms-auto lh-1">
        </div>
        <?php #########################chart-active-users-top################################ ?>
        <div class="table-responsive mt-3">
            <?php $this->load->view('dashboard/chart_fan_set_top_sensor_card_dashboard4'); ?>
        </div>
        <div class="table-responsive mt-3">
            <?php  $this->load->view('dashboard/cardtable_data_dashboard4');  ?>
        </div>

        <?php #########################chart-active-users-top################################ ?>
    </div>
</div>

<script src="<?php echo base_url('assets');?>/js/chart.js" defer></script>
<script src="<?php echo base_url('assets');?>/js/chartjs-plugin-zoom.js" defer></script>
<style>
.chart-responsive {
    position: relative;
    width: 100%;
    min-height: 200px;
}

@media (max-width: 576px) {
    .chart-responsive {
        min-height: 150px;
    }
}

.dashboard-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    /* สร้าง 4 คอลัมน์ */
    row-gap: 2px;
    /* เว้นระยะห่างระหว่างแถวในแนวสูง 2px */
    column-gap: 2px;
    /* เว้นระยะห่างระหว่างคอลัมน์ในแนวนอน 2px */
}

/* หรือใช้คำสั่งย่อ 'gap' */
.dashboard-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2px;
    /* เว้นระยะห่าง 2px ทั้งแนวตั้งและแนวนอน */
}
</style>