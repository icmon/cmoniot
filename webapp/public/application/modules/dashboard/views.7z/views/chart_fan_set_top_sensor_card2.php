<?php for($i=1;$i<=4;$i++): 
$floor=$i;
$podium=$i;
$senser_no=$i;
$cenrent=$i;
$fan1=$i;
$fan2=$i;
$nuittemp='°C';
if($i==1){
    $sensor_name='BAACTW02';
}else if($i==2){
    $sensor_name='BAACTW03';
}else if($i==3){
    $sensor_name='BAACTW04';
}else if($i==4){
    $sensor_name='BAACTW05';
}else{
    $sensor_name='BAACTW02';
}

?>
<?php ####################### ?>
<?php ####################
/*
 http://localhost/cmonphpiot/api/iot/devicemonitor?bucket=BAACTW03
*/
?>

<div class="col-sm-6 col-lg-3">
    <div class="card">
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="subheader">
                    <span id="sensor-name-<?php echo $i;?>"> <?php echo $sensor_name;?></span> | Temperature :
                    <span id="temperature-<?php echo $i;?>">--</span>
                    <b><?php echo $nuittemp;?></b>
                    <div id="podium<?php echo $i;?>-status">
                        <div class="row g-3 align-items-center mb-2 center">
                            <div class="col-auto">
                                <span id="fan1-dot_<?php echo $i;?>"
                                    class="status-indicator status-red status-indicator-animated">
                                    <span class="status-indicator-circle"></span>
                                    <span class="status-indicator-circle"></span>
                                    <span class="status-indicator-circle"></span>
                                </span>
                                <span class="d-inline-block"
                                    style="font-size:1.1rem;font-weight:600; margin-left:6px;">FAN 1</span>
                                <span id="fan1-status-<?php echo $i;?>" class="text-danger"
                                    style="margin-left:6px;">OFF</span>

                            </div>
                            <div class="col-auto">
                                <span id="fan2-dot_<?php echo $i;?>"
                                    class="status-indicator status-red status-indicator-animated">
                                    <span class="status-indicator-circle"></span>
                                    <span class="status-indicator-circle"></span>
                                    <span class="status-indicator-circle"></span>
                                </span>
                                <span class="d-inline-block"
                                    style="font-size:1.1rem;font-weight:600; margin-left:6px;">FAN 2</span>
                                <span id="fan2-status-<?php echo $i;?>" class="text-danger"
                                    style="margin-left:6px;">OFF</span>
                            </div>
                            <div class="col-auto">
                                <span id="alert-dot_<?php echo $i;?>"
                                    class="status-indicator status-red status-indicator-animated">
                                    <span class="status-indicator-circle"></span>
                                    <span class="status-indicator-circle"></span>
                                    <span class="status-indicator-circle"></span>
                                </span>
                                <span class="d-inline-block"
                                    style="font-size:1.1rem;font-weight:600; margin-left:6px;">Alerts </span>
                                <span id="alert-status-<?php echo $i;?>" class="text-danger"
                                    style="margin-left:6px;">OFF</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="chart-temperature-<?php echo $i;?>" class="position-relative rounded-bottom chart-sm"></div>
    </div>
</div>

<?php #################### ?>
<?php ####################### ?>
<?php ####################### ?>
<script>
function updateStatus_<?php echo $i;?>(dotId, textId, value) {
    if (value == 1) {
        $('#' + dotId).removeClass('status-red').addClass('status-green');
        $('#' + textId).removeClass('text-danger').addClass('text-success').text('ON');
    } else {
        $('#' + dotId).removeClass('status-green').addClass('status-red');
        $('#' + textId).removeClass('text-success').addClass('text-danger').text('OFF');
    }
}

let tempChart_<?php echo $i;?>;

function fetchAndUpdate_<?php echo $i;?>() {
    $.getJSON('<?php echo base_url($this->config->item('api_iot_devicemonitor'));?><?php echo $sensor_name;?>',
        function(data) {
            // console.log('data');
            // console.info(data);
            // console.log('value');
            // console.info(data.value);
            // console.log('alert');
            // console.info(data.alert);
            // console.log('fan1');
            // console.info(data.fan1);
            // console.log('fan2');
            // console.info(data.fan2.data);
            // console.log('chart_data');
            // console.info(data.chart.data);
            // console.log('chart_date');
            // console.info(data.chart.date);

            // อัปเดตค่าที่แสดงผล
            $('#temperature-<?php echo $i;?>').text(data.value);
            updateStatus_<?php echo $i;?>('fan1-dot_<?php echo $i;?>', 'fan1-status-<?php echo $i;?>', data.fan1);
            updateStatus_<?php echo $i;?>('fan2-dot_<?php echo $i;?>', 'fan2-status-<?php echo $i;?>', data.fan2);
            updateStatus_<?php echo $i;?>('alert-dot_<?php echo $i;?>', 'alert-status-<?php echo $i;?>', data
                .alert);
            // อัปเดตกราฟ (ถ้ามี)
            if (tempChart_<?php echo $i;?> && data.chart && data.chart.data) {
                tempChart_<?php echo $i;?>.updateSeries([data.chart.data]);
            }
        });
}

document.addEventListener("DOMContentLoaded", function() {
    /*
    tempChart_<?php echo $i;?> = new ApexCharts(document.getElementById('chart-temperature-<?php echo $i;?>'), {
        chart: {
            type: "line",
            height: 80,
            sparkline: {
                enabled: true
            },
            animations: {
                enabled: true
            }
        },
        series: [{
            data: []
        }],
        stroke: {
            curve: 'smooth',
            width: 2
        },
        colors: ['#00d97e'],
        tooltip: {
            enabled: false
        },
        grid: {
            show: false
        },
        xaxis: {
            labels: {
                show: false
            },
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            }
        },
        yaxis: {
            show: false
        }
    });
    tempChart_<?php echo $i;?>.render();
    */
    let chart = null;
    const options = {
        chart: {
            type: "line",
            fontFamily: 'inherit',
            height: 80,
            parentHeightOffset: 0,
            toolbar: {
                show: false
            },
            animations: {
                enabled: true
            },
            stacked: true,
        },
        dataLabels: {
            enabled: false
        },
        fill: {
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 16%)',
                'color-mix(in srgb, transparent, var(--tblr-primary) 16%)',
            ],
            type: 'solid'
        },
        stroke: {
            width: 2,
            lineCap: "round",
            curve: "smooth",
        },
        series: [{
            name: "",
            data: []
        }],
        tooltip: {
            theme: 'dark',
            x: {
                format: 'dd MMM yyyy HH:mm :ss'
            }
        },
        grid: {
            padding: {
                top: -20,
                right: 0,
                left: -4,
                bottom: -4
            },
            strokeDashArray: 4,
        },
        xaxis: {
            type: 'datetime', // เปลี่ยนจาก 'category' เป็น 'datetime'
            labels: {
                datetimeUTC: false,
                format: 'dd MMM HH:mm :ss',
                // formatter: undefined // ให้ ApexCharts จัดการเอง
            },
            tooltip: {
                enabled: true
            },
            axisBorder: {
                show: true
            },
        },
        yaxis: {
            labels: {
                padding: 4,
                formatter: function(val) {
                    return val + " °C"
                }
            }
        },
        legend: {
            show: true
        },
        colors: [
            'color-mix(in srgb, transparent, var(--tblr-primary) 100%)',
            'color-mix(in srgb, transparent, var(--tblr-red) 80%)'
        ]
    };
    chart = new ApexCharts(document.getElementById('chart-temperature-<?php echo $i;?>'), options);
    chart.render();
    async function fetchAndUpdateChart() {
        try {
            const response = await fetch(
                '<?php echo base_url($this->config->item('api_iot_devicemonitor'));?><?php echo $sensor_name;?>'
            );
            const data = await response.json();
            const measurement = data.bucket;
            const chartData = data.chart.data;
            // console.log('dmeasurementata');
            // console.info(measurement);
            // console.log('chartData');
            // console.info(chartData);

            // สมมติ data.chart.date เป็น array ของวันที่ในรูปแบบ 'YYYY-MM-DD HH:mm:ss'
            // แปลงเป็น timestamp หรือ ISO string
            const labels = data.chart.date.map(dt => new Date(dt).toISOString());

            // สร้าง array ของ object {x: datetime, y: value}
            const seriesData = labels.map((dt, idx) => ({
                x: dt,
                y: chartData[idx]
            }));

            chart.updateOptions({
                series: [{
                    name: measurement,
                    data: seriesData
                }]
            });
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    fetchAndUpdateChart();
    setInterval(fetchAndUpdateChart, <?php echo $this->config->item('api_call_time');?>);
    /*******************/
    fetchAndUpdate_<?php echo $i;?>();
    setInterval(fetchAndUpdate_<?php echo $i;?>,
    <?php echo $this->config->item('api_call_time');?>); // 10 วินาที
});
</script>

<?php endfor; ?>
<style>
.status-indicator.status-green .status-indicator-circle {
    background: #00d97e !important;
    box-shadow: 0 0 6px #00d97e;
}

.status-indicator.status-red .status-indicator-circle {
    background: #fa5252 !important;
    box-shadow: 0 0 6px #fa5252;
}
</style>
<style>
.chart-responsive {
    position: relative;
    width: 100%;
    min-height: 200px;
}

@media (max-width: 576px) {
    .chart-responsive {
        min-height: 150px;
    }
}
</style>