<!-- BEGIN PAGE SCRIPTS -->

<!--- chart-active-users-1-->
<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-active-users-1"] = new ApexCharts(document
        .getElementById('chart-active-users-1'), {
            chart: {
                type: "radialBar",
                fontFamily: 'inherit',
                height: 192,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            plotOptions: {
                radialBar: {
                    startAngle: -180,
                    endAngle: 180,
                    hollow: {
                        margin: 16,
                        size: "50%"
                    },
                    dataLabels: {
                        show: true,
                        value: {
                            offsetY: -8,
                            fontSize: '24px',
                        }
                    },
                },
            },
            series: [59.89],
            labels: [""],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 4,
            },
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>

<!--- chart-active-users-2-->
<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-active-users-2"] = new ApexCharts(document
        .getElementById('chart-active-users-2'), {
            chart: {
                type: "radialBar",
                fontFamily: 'inherit',
                height: 192,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            plotOptions: {
                radialBar: {
                    startAngle: -180,
                    endAngle: 180,
                    hollow: {
                        margin: 16,
                        size: "50%"
                    },
                    dataLabels: {
                        show: true,
                        value: {
                            offsetY: -8,
                            fontSize: '24px',
                        }
                    },
                },
            },
            series: [78],
            labels: [""],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 4,
            },
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>

<!--- chart-active-users-3-->
<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-active-users-3"] = new ApexCharts(document
        .getElementById('chart-active-users-3'), {
            chart: {
                type: "radialBar",
                fontFamily: 'inherit',
                height: 192,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: true
                },
            },
            plotOptions: {
                radialBar: {
                    startAngle: -180,
                    endAngle: 180,
                    hollow: {
                        margin: 16,
                        size: "50%"
                    },
                    dataLabels: {
                        show: true,
                        value: {
                            offsetY: -8,
                            fontSize: '24px',
                        }
                    },
                },
            },
            series: [76],
            labels: [""],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 5,
            },
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>


<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-revenue-bg"] = new ApexCharts(document
        .getElementById('chart-revenue-bg'), {
            chart: {
                type: "area",
                fontFamily: 'inherit',
                height: 40,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            dataLabels: {
                enabled: false,
            },
            fill: {
                colors: [
                    'color-mix(in srgb, transparent, var(--tblr-primary) 16%)',
                    'color-mix(in srgb, transparent, var(--tblr-primary) 16%)',
                ],
                type: 'solid'
            },
            stroke: {
                width: 2,
                lineCap: "round",
                curve: "smooth",
            },
            series: [{
                name: "Profits",
                data: [37, 35, 44, 28, 36, 24, 65, 31, 37, 39, 62, 51, 35, 41, 35, 27,
                    93, 53, 61, 27, 54, 43, 19, 46, 39, 62, 51, 35, 41, 67
                ]
            }],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 4,
            },
            xaxis: {
                labels: {
                    padding: 0,
                },
                tooltip: {
                    enabled: false
                },
                axisBorder: {
                    show: false,
                },
                type: 'datetime',
            },
            yaxis: {
                labels: {
                    padding: 4
                },
            },
            labels: [
                '2020-06-20', '2020-06-21', '2020-06-22', '2020-06-23', '2020-06-24',
                '2020-06-25', '2020-06-26', '2020-06-27', '2020-06-28', '2020-06-29',
                '2020-06-30', '2020-07-01', '2020-07-02', '2020-07-03', '2020-07-04',
                '2020-07-05', '2020-07-06', '2020-07-07', '2020-07-08', '2020-07-09',
                '2020-07-10', '2020-07-11', '2020-07-12', '2020-07-13', '2020-07-14',
                '2020-07-15', '2020-07-16', '2020-07-17', '2020-07-18', '2020-07-19'
            ],
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-new-clients"] = new ApexCharts(document
        .getElementById('chart-new-clients'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 40,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            stroke: {
                width: [2, 1],
                dashArray: [0, 3],
                lineCap: "round",
                curve: "smooth",
            },
            series: [{
                name: "May",
                data: [37, 35, 44, 28, 36, 24, 65, 31, 37, 39, 62, 51, 35, 41, 35, 27,
                    93, 53, 61, 27, 54, 43, 4, 46, 39, 62, 51, 35, 41, 67
                ]
            }, {
                name: "April",
                data: [93, 54, 51, 24, 35, 35, 31, 67, 19, 43, 28, 36, 62, 61, 27, 39,
                    35, 41, 27, 35, 51, 46, 62, 37, 44, 53, 41, 65, 39, 37
                ]
            }],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 4,
            },
            xaxis: {
                labels: {
                    padding: 0,
                },
                tooltip: {
                    enabled: false
                },
                type: 'datetime',
            },
            yaxis: {
                labels: {
                    padding: 4
                },
            },
            labels: [
                '2020-06-20', '2020-06-21', '2020-06-22', '2020-06-23', '2020-06-24',
                '2020-06-25', '2020-06-26', '2020-06-27', '2020-06-28', '2020-06-29',
                '2020-06-30', '2020-07-01', '2020-07-02', '2020-07-03', '2020-07-04',
                '2020-07-05', '2020-07-06', '2020-07-07', '2020-07-08', '2020-07-09',
                '2020-07-10', '2020-07-11', '2020-07-12', '2020-07-13', '2020-07-14',
                '2020-07-15', '2020-07-16', '2020-07-17', '2020-07-18', '2020-07-19'
            ],
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)',
                'color-mix(in srgb, transparent, var(--tblr-gray-600) 100%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-active-users"] = new ApexCharts(document
        .getElementById('chart-active-users'), {
            chart: {
                type: "bar",
                fontFamily: 'inherit',
                height: 40,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            plotOptions: {
                bar: {
                    columnWidth: '50%',
                }
            },
            dataLabels: {
                enabled: false,
            },
            series: [{
                name: "Profits",
                data: [37, 35, 44, 28, 36, 24, 65, 31, 37, 39, 62, 51, 35, 41, 35, 27,
                    93, 53, 61, 27, 54, 43, 19, 46, 39, 62, 51, 35, 41, 67
                ]
            }],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 4,
            },
            xaxis: {
                labels: {
                    padding: 0,
                },
                tooltip: {
                    enabled: false
                },
                axisBorder: {
                    show: false,
                },
                type: 'datetime',
            },
            yaxis: {
                labels: {
                    padding: 4
                },
            },
            labels: [
                '2020-06-20', '2020-06-21', '2020-06-22', '2020-06-23', '2020-06-24',
                '2020-06-25', '2020-06-26', '2020-06-27', '2020-06-28', '2020-06-29',
                '2020-06-30', '2020-07-01', '2020-07-02', '2020-07-03', '2020-07-04',
                '2020-07-05', '2020-07-06', '2020-07-07', '2020-07-08', '2020-07-09',
                '2020-07-10', '2020-07-11', '2020-07-12', '2020-07-13', '2020-07-14',
                '2020-07-15', '2020-07-16', '2020-07-17', '2020-07-18', '2020-07-19'
            ],
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-mentions"] = new ApexCharts(document
        .getElementById('chart-mentions'), {
            chart: {
                type: "bar",
                fontFamily: 'inherit',
                height: 240,
                parentHeightOffset: 0,
                toolbar: {
                    show: false,
                },
                animations: {
                    enabled: false
                },
                stacked: true,
            },
            plotOptions: {
                bar: {
                    columnWidth: '50%',
                }
            },
            dataLabels: {
                enabled: false,
            },
            series: [{
                name: "Web",
                data: [1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 2, 12, 5, 8, 22, 6, 8, 6, 4, 1, 8,
                    24, 29, 51, 40, 47, 23, 26, 50, 26, 41, 22, 46, 47, 81, 46, 6
                ]
            }, {
                name: "Social",
                data: [2, 5, 4, 3, 3, 1, 4, 7, 5, 1, 2, 5, 3, 2, 6, 7, 7, 1, 5, 5, 2,
                    12, 4, 6, 18, 3, 5, 2, 13, 15, 20, 47, 18, 15, 11, 10, 0
                ]
            }, {
                name: "Other",
                data: [2, 9, 1, 7, 8, 3, 6, 5, 5, 4, 6, 4, 1, 9, 3, 6, 7, 5, 2, 8, 4, 9,
                    1, 2, 6, 7, 5, 1, 8, 3, 2, 3, 4, 9, 7, 1, 6
                ]
            }],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                padding: {
                    top: -20,
                    right: 0,
                    left: -4,
                    bottom: -4
                },
                strokeDashArray: 4,
                xaxis: {
                    lines: {
                        show: true
                    }
                },
            },
            xaxis: {
                labels: {
                    padding: 0,
                },
                tooltip: {
                    enabled: false
                },
                axisBorder: {
                    show: false,
                },
                type: 'datetime',
            },
            yaxis: {
                labels: {
                    padding: 4
                },
            },
            labels: [
                '2020-06-20', '2020-06-21', '2020-06-22', '2020-06-23', '2020-06-24',
                '2020-06-25', '2020-06-26', '2020-06-27', '2020-06-28', '2020-06-29',
                '2020-06-30', '2020-07-01', '2020-07-02', '2020-07-03', '2020-07-04',
                '2020-07-05', '2020-07-06', '2020-07-07', '2020-07-08', '2020-07-09',
                '2020-07-10', '2020-07-11', '2020-07-12', '2020-07-13', '2020-07-14',
                '2020-07-15', '2020-07-16', '2020-07-17', '2020-07-18', '2020-07-19',
                '2020-07-20', '2020-07-21', '2020-07-22', '2020-07-23', '2020-07-24',
                '2020-07-25', '2020-07-26'
            ],
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)',
                'color-mix(in srgb, transparent, var(--tblr-primary) 80%)',
                'color-mix(in srgb, transparent, var(--tblr-green) 80%)'
            ],
            legend: {
                show: false,
            },
        })).render();
});
</script>

<script>
window.tabler_map_vector = window.tabler_map_vector || {};
document.addEventListener("DOMContentLoaded", function() {
    const map = window.tabler_map_vector["map-world"] = new jsVectorMap({
        selector: '#map-world',
        map: 'world',
        backgroundColor: 'transparent',
        regionStyle: {
            initial: {
                fill: 'var(--tblr-bg-surface-secondary)',
                stroke: 'var(--tblr-border-color)',
                strokeWidth: 2,
            }
        },
        zoomOnScroll: false,
        zoomButtons: false,
        series: {
            regions: [{
                attribute: "fill",
                scale: {
                    scale1: 'color-mix(in srgb, transparent, var(--tblr-primary) 10%)',
                    scale2: 'color-mix(in srgb, transparent, var(--tblr-primary) 20%)',
                    scale3: 'color-mix(in srgb, transparent, var(--tblr-primary) 30%)',
                    scale4: 'color-mix(in srgb, transparent, var(--tblr-primary) 40%)',
                    scale5: 'color-mix(in srgb, transparent, var(--tblr-primary) 50%)',
                    scale6: 'color-mix(in srgb, transparent, var(--tblr-primary) 60%)',
                    scale7: 'color-mix(in srgb, transparent, var(--tblr-primary) 70%)',
                    scale8: 'color-mix(in srgb, transparent, var(--tblr-primary) 80%)',
                    scale9: 'color-mix(in srgb, transparent, var(--tblr-primary) 90%)',
                    scale10: 'color-mix(in srgb, transparent, var(--tblr-primary) 100%)',
                },
                values: {
                    "AF": "scale2",
                    "AL": "scale2",
                    "DZ": "scale4",
                    "AO": "scale3",
                    "AG": "scale1",
                    "AR": "scale5",
                    "AM": "scale1",
                    "AU": "scale7",
                    "AT": "scale5",
                    "AZ": "scale3",
                    "BS": "scale1",
                    "BH": "scale2",
                    "BD": "scale4",
                    "BB": "scale1",
                    "BY": "scale3",
                    "BE": "scale5",
                    "BZ": "scale1",
                    "BJ": "scale1",
                    "BT": "scale1",
                    "BO": "scale2",
                    "BA": "scale2",
                    "BW": "scale2",
                    "BR": "scale8",
                    "BN": "scale2",
                    "BG": "scale2",
                    "BF": "scale1",
                    "BI": "scale1",
                    "KH": "scale2",
                    "CM": "scale2",
                    "CA": "scale7",
                    "CV": "scale1",
                    "CF": "scale1",
                    "TD": "scale1",
                    "CL": "scale4",
                    "CN": "scale9",
                    "CO": "scale5",
                    "KM": "scale1",
                    "CD": "scale2",
                    "CG": "scale2",
                    "CR": "scale2",
                    "CI": "scale2",
                    "HR": "scale3",
                    "CY": "scale2",
                    "CZ": "scale4",
                    "DK": "scale5",
                    "DJ": "scale1",
                    "DM": "scale1",
                    "DO": "scale3",
                    "EC": "scale3",
                    "EG": "scale5",
                    "SV": "scale2",
                    "GQ": "scale2",
                    "ER": "scale1",
                    "EE": "scale2",
                    "ET": "scale2",
                    "FJ": "scale1",
                    "FI": "scale5",
                    "FR": "scale8",
                    "GA": "scale2",
                    "GM": "scale1",
                    "GE": "scale2",
                    "DE": "scale8",
                    "GH": "scale2",
                    "GR": "scale5",
                    "GD": "scale1",
                    "GT": "scale2",
                    "GN": "scale1",
                    "GW": "scale1",
                    "GY": "scale1",
                    "HT": "scale1",
                    "HN": "scale2",
                    "HK": "scale5",
                    "HU": "scale4",
                    "IS": "scale2",
                    "IN": "scale7",
                    "ID": "scale6",
                    "IR": "scale5",
                    "IQ": "scale3",
                    "IE": "scale5",
                    "IL": "scale5",
                    "IT": "scale8",
                    "JM": "scale2",
                    "JP": "scale9",
                    "JO": "scale2",
                    "KZ": "scale4",
                    "KE": "scale2",
                    "KI": "scale1",
                    "KR": "scale6",
                    "KW": "scale4",
                    "KG": "scale1",
                    "LA": "scale1",
                    "LV": "scale2",
                    "LB": "scale2",
                    "LS": "scale1",
                    "LR": "scale1",
                    "LY": "scale3",
                    "LT": "scale2",
                    "LU": "scale3",
                    "MK": "scale1",
                    "MG": "scale1",
                    "MW": "scale1",
                    "MY": "scale5",
                    "MV": "scale1",
                    "ML": "scale1",
                    "MT": "scale1",
                    "MR": "scale1",
                    "MU": "scale1",
                    "MX": "scale7",
                    "MD": "scale1",
                    "MN": "scale1",
                    "ME": "scale1",
                    "MA": "scale3",
                    "MZ": "scale2",
                    "MM": "scale2",
                    "NA": "scale2",
                    "NP": "scale2",
                    "NL": "scale6",
                    "NZ": "scale4",
                    "NI": "scale1",
                    "NE": "scale1",
                    "NG": "scale5",
                    "NO": "scale5",
                    "OM": "scale3",
                    "PK": "scale4",
                    "PA": "scale2",
                    "PG": "scale1",
                    "PY": "scale2",
                    "PE": "scale4",
                    "PH": "scale4",
                    "PL": "scale10",
                    "PT": "scale5",
                    "QA": "scale4",
                    "RO": "scale4",
                    "RU": "scale7",
                    "RW": "scale1",
                    "WS": "scale1",
                    "ST": "scale1",
                    "SA": "scale5",
                    "SN": "scale2",
                    "RS": "scale2",
                    "SC": "scale1",
                    "SL": "scale1",
                    "SG": "scale5",
                    "SK": "scale3",
                    "SI": "scale2",
                    "SB": "scale1",
                    "ZA": "scale5",
                    "ES": "scale7",
                    "LK": "scale2",
                    "KN": "scale1",
                    "LC": "scale1",
                    "VC": "scale1",
                    "SD": "scale3",
                    "SR": "scale1",
                    "SZ": "scale1",
                    "SE": "scale5",
                    "CH": "scale6",
                    "SY": "scale3",
                    "TW": "scale5",
                    "TJ": "scale1",
                    "TZ": "scale2",
                    "TH": "scale5",
                    "TL": "scale1",
                    "TG": "scale1",
                    "TO": "scale1",
                    "TT": "scale2",
                    "TN": "scale2",
                    "TR": "scale6",
                    "TM": "scale1",
                    "UG": "scale2",
                    "UA": "scale4",
                    "AE": "scale5",
                    "GB": "scale8",
                    "US": "scale10",
                    "UY": "scale2",
                    "UZ": "scale2",
                    "VU": "scale1",
                    "VE": "scale5",
                    "VN": "scale4",
                    "YE": "scale2",
                    "ZM": "scale2",
                    "ZW": "scale1"
                },
            }]
        }
    });
    window.addEventListener("resize", () => {
        map.updateSize();
    });
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-activity"] = new ApexCharts(document
        .getElementById('sparkline-activity'), {
            chart: {
                type: "radialBar",
                fontFamily: 'inherit',
                height: 40,
                width: 40,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            plotOptions: {
                radialBar: {
                    hollow: {
                        margin: 0,
                        size: '75%'
                    },
                    track: {
                        margin: 0
                    },
                    dataLabels: {
                        show: false
                    }
                }
            },
            colors: ['var(--tblr-primary)'],
            series: [35],
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["chart-development-activity"] = new ApexCharts(document
        .getElementById('chart-development-activity'), {
            chart: {
                type: "area",
                fontFamily: 'inherit',
                height: 192,
                sparkline: {
                    enabled: true
                },
                animations: {
                    enabled: false
                },
            },
            dataLabels: {
                enabled: false,
            },
            fill: {
                colors: [
                    'color-mix(in srgb, transparent, var(--tblr-primary) 16%)',
                    'color-mix(in srgb, transparent, var(--tblr-primary) 16%)',
                ],
                type: 'solid'
            },
            stroke: {
                width: 2,
                lineCap: "round",
                curve: "smooth",
            },
            series: [{
                name: "Purchases",
                data: [3, 5, 4, 6, 7, 5, 6, 8, 24, 7, 12, 5, 6, 3, 8, 4, 14, 30, 17, 19,
                    15, 14, 25, 32, 40, 55, 60, 48, 52, 70
                ]
            }],
            tooltip: {
                theme: 'dark'
            },
            grid: {
                strokeDashArray: 4,
            },
            xaxis: {
                labels: {
                    padding: 0,
                },
                tooltip: {
                    enabled: false
                },
                axisBorder: {
                    show: false,
                },
                type: 'datetime',
            },
            yaxis: {
                labels: {
                    padding: 4
                },
            },
            labels: [
                '2020-06-20', '2020-06-21', '2020-06-22', '2020-06-23', '2020-06-24',
                '2020-06-25', '2020-06-26', '2020-06-27', '2020-06-28', '2020-06-29',
                '2020-06-30', '2020-07-01', '2020-07-02', '2020-07-03', '2020-07-04',
                '2020-07-05', '2020-07-06', '2020-07-07', '2020-07-08', '2020-07-09',
                '2020-07-10', '2020-07-11', '2020-07-12', '2020-07-13', '2020-07-14',
                '2020-07-15', '2020-07-16', '2020-07-17', '2020-07-18', '2020-07-19'
            ],
            colors: [
                'color-mix(in srgb, transparent, var(--tblr-primary) 100%)'
            ],
            legend: {
                show: false,
            },
            point: {
                show: false
            },
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-bounce-rate-1"] = new ApexCharts(document
        .getElementById('sparkline-bounce-rate-1'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 24,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            stroke: {
                width: 2,
                lineCap: "round",
            },
            series: [{
                color: 'var(--tblr-primary)',
                data: [17, 24, 20, 10, 5, 1, 4, 18, 13]
            }],
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-bounce-rate-2"] = new ApexCharts(document
        .getElementById('sparkline-bounce-rate-2'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 24,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            stroke: {
                width: 2,
                lineCap: "round",
            },
            series: [{
                color: 'var(--tblr-primary)',
                data: [13, 11, 19, 22, 12, 7, 14, 3, 21]
            }],
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-bounce-rate-3"] = new ApexCharts(document
        .getElementById('sparkline-bounce-rate-3'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 24,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            stroke: {
                width: 2,
                lineCap: "round",
            },
            series: [{
                color: 'var(--tblr-primary)',
                data: [10, 13, 10, 4, 17, 3, 23, 22, 19]
            }],
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-bounce-rate-4"] = new ApexCharts(document
        .getElementById('sparkline-bounce-rate-4'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 24,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            stroke: {
                width: 2,
                lineCap: "round",
            },
            series: [{
                color: 'var(--tblr-primary)',
                data: [6, 15, 13, 13, 5, 7, 17, 20, 19]
            }],
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-bounce-rate-5"] = new ApexCharts(document
        .getElementById('sparkline-bounce-rate-5'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 24,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            stroke: {
                width: 2,
                lineCap: "round",
            },
            series: [{
                color: 'var(--tblr-primary)',
                data: [2, 11, 15, 14, 21, 20, 8, 23, 18, 14]
            }],
        })).render();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    window.tabler_chart = window.tabler_chart || {};
    window.ApexCharts && (window.tabler_chart["sparkline-bounce-rate-6"] = new ApexCharts(document
        .getElementById('sparkline-bounce-rate-6'), {
            chart: {
                type: "line",
                fontFamily: 'inherit',
                height: 24,
                animations: {
                    enabled: false
                },
                sparkline: {
                    enabled: true
                },
            },
            tooltip: {
                enabled: false,
            },
            stroke: {
                width: 2,
                lineCap: "round",
            },
            series: [{
                color: 'var(--tblr-primary)',
                data: [22, 12, 7, 14, 3, 21, 8, 23, 18, 14]
            }],
        })).render();
});
</script>

<?php   
/*

SN: "DFADBEEFFEEF"
Temperature: "29.93"
Current: "3.33"
Relay1: "0"
Relay2: "1"

*/

?>